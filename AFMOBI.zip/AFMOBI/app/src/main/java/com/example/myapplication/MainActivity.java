package com.example.myapplication;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText editNomeItem, editQuantidade;
    private Button btnAdicionar;
    private RecyclerView recyclerViewLista;
    private ArrayList<ItemCompra> itemList;
    private ItemAdapter itemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editNomeItem = findViewById(R.id.editNomeItem);
        editQuantidade = findViewById(R.id.editQuantidade);
        btnAdicionar = findViewById(R.id.btnAdicionar);
        recyclerViewLista = findViewById(R.id.recyclerViewLista);

        itemList = new ArrayList<>();
        itemAdapter = new ItemAdapter(itemList, this);

        recyclerViewLista.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewLista.setAdapter(itemAdapter);

        btnAdicionar.setOnClickListener(v -> {
            String nome = editNomeItem.getText().toString();
            String qtdStr = editQuantidade.getText().toString();

            if (nome.isEmpty() || qtdStr.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }

            String quantidade = String.valueOf(Integer.parseInt(qtdStr));
            itemList.add(new ItemCompra(nome, quantidade));
            itemAdapter.notifyDataSetChanged();

            editNomeItem.setText("");
            editQuantidade.setText("");
        });
    }
}
