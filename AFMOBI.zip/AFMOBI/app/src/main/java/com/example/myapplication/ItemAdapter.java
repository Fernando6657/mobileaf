package com.example.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private List<ItemCompra> itemList;
    private Context context;

    public ItemAdapter(List<ItemCompra> itemList, Context context) {
        this.itemList = itemList;
        this.context = context;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkComprado;
        TextView textItem;

        public ViewHolder(View itemView) {
            super(itemView);
            checkComprado = itemView.findViewById(R.id.checkComprado);
            textItem = itemView.findViewById(R.id.textItem);
        }
    }

    @NonNull
    @Override
    public ItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_lista, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ItemCompra item = itemList.get(position);
        holder.textItem.setText(item.getNome() + " - Qtd: " + item.getQuantidade());

        holder.checkComprado.setOnCheckedChangeListener(null);
        holder.checkComprado.setChecked(item.isComprado());

        holder.checkComprado.setOnCheckedChangeListener((buttonView, isChecked) -> {
            item.setComprado(isChecked);
            if (isChecked) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Informe o preço (por unidade ou quilo)");

                final EditText input = new EditText(context);
                input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                builder.setView(input);

                builder.setPositiveButton("OK", (dialog, which) -> {
                    String preco = input.getText().toString();
                    item.setPreco(preco);
                    notifyDataSetChanged();
                });

                builder.setNegativeButton("Cancelar", (dialog, which) -> {
                    item.setComprado(false);
                    notifyDataSetChanged();
                });

                builder.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }
}
