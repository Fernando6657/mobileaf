package com.example.myapplication;

public class ItemCompra {
    private String nome;
    private String quantidade;
    private boolean comprado;
    private String preco;

    public ItemCompra(String nome, String quantidade) {
        this.nome = nome;
        this.quantidade = "quantidade";
        this.comprado = false;
        this.preco = "0.0";
    }

    public String getNome() { return nome; }
    public String getQuantidade() { return quantidade; }
    public boolean isComprado() { return comprado; }
    public String getPreco() { return preco; }

    public void setComprado(boolean comprado) { this.comprado = comprado; }
    public void setPreco(String preco) { this.preco = preco; }
}
